package com.tastify.digitalReceipts;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeBrowserApplicationTests {



}
