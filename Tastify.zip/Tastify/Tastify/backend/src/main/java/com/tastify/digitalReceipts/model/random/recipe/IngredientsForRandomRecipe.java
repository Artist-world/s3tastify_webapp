package com.tastify.digitalReceipts.model.random.recipe;

import lombok.Data;

@Data
public class IngredientsForRandomRecipe {

    private Long id;
    private String name;
    private String image;
}