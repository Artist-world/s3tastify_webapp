package com.tastify.digitalReceipts.model.recipe.information;

import lombok.Data;

@Data
public class WeightPerServing {

    public Integer amount;
    public String unit;
}
