package com.tastify.digitalReceipts.model.recipe.information;

import lombok.Data;

@Data
public class Units {

    public Double amount;
    public String unitShort;
    public String unitLong;
}
